# Bad_review_detection
### 描述：
该项目基于数据集“COLDataset”进行搭建，主要是敏感类不良言论的分类识别。
- 类别：0（Normal）1(UnNormal)
- 数据集：COL/data，包含训练数据
- 使用：运行文件run.py，注意各个文件的文件路径改写已经环境变量的配置。
### 注意：
- 请尊重数据版权
- 数据类别可能存在一些错误，请自行调整
- 项目仅是个人学习使用，Git也是为了以后回顾方便查找和管理，请勿违法使用和商用。git_URL:https://github.com/EthanLiu6/Bad_review_detection.git
- 版权 © 2023 刘爱辉（Ethan_Liu）
